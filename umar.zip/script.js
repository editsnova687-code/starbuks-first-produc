const vids=[...document.querySelectorAll('.bg video')];
let cur=-1;
// Intro: naam dikhne ke baad hat jata hai (2.8 sec)
setTimeout(()=>{
  document.getElementById('intro').classList.add('hide');
  document.body.classList.remove('loading');
  setTimeout(()=>document.getElementById('intro').remove(),1300);
},2800);
function show(i){
  if(i===cur)return;cur=i;
  document.querySelectorAll('.dots a').forEach((d,k)=>d.classList.toggle('on',k===i));
  vids.forEach((v,k)=>{
    if(k===i){v.classList.add('on');v.play().catch(()=>{})}
    else{v.classList.remove('on');setTimeout(()=>{if(cur!==k)v.pause()},1300)}
  });
}
show(0);
// Section badalte hi video change
const io=new IntersectionObserver(es=>es.forEach(e=>{
  if(e.isIntersecting){
    show(+e.target.dataset.v);
    e.target.classList.add('act');
    e.target.querySelectorAll('.stats div').forEach(c=>count(c));
  }
}),{threshold:.5});
document.querySelectorAll('section').forEach(s=>io.observe(s));
// counters
function count(el){
  if(el.done)return;el.done=true;
  const n=+el.dataset.n,s=el.querySelector('small');let t=0;
  const id=setInterval(()=>{t+=Math.ceil(n/60);if(t>=n){t=n;clearInterval(id)}
    el.firstChild.nodeValue=t.toLocaleString()+'+'},25);
}
// cursor
const c=document.getElementById('cur');
addEventListener('mousemove',e=>{c.style.left=e.clientX+'px';c.style.top=e.clientY+'px'});
document.querySelectorAll('a,.card').forEach(a=>{
  a.addEventListener('mouseenter',()=>c.classList.add('big'));
  a.addEventListener('mouseleave',()=>c.classList.remove('big'));
});
// magnetic buttons
document.querySelectorAll('.mag').forEach(b=>{
  b.addEventListener('mousemove',e=>{const r=b.getBoundingClientRect();
    b.style.transform=`translate(${(e.clientX-r.left-r.width/2)*.3}px,${(e.clientY-r.top-r.height/2)*.4}px)`});
  b.addEventListener('mouseleave',()=>b.style.transform='');
});
// 3D tilt cards
document.querySelectorAll('.card').forEach(k=>{
  k.addEventListener('mousemove',e=>{const r=k.getBoundingClientRect();
    const x=(e.clientX-r.left)/r.width-.5,y=(e.clientY-r.top)/r.height-.5;
    k.style.transform=`perspective(700px) rotateY(${x*16}deg) rotateX(${-y*16}deg) translateY(-8px)`});
  k.addEventListener('mouseleave',()=>k.style.transform='');
});
// ===== Order menu =====
const mn=document.getElementById('menu'),totEl=document.getElementById('tot'),okEl=document.getElementById('ok');
const rows=[...mn.querySelectorAll('.mrow')];
function openMenu(){mn.classList.add('open');document.body.style.overflow='hidden'}
function closeMenu(){mn.classList.remove('open');document.body.style.overflow=''}
function total(){let t=0;rows.forEach(r=>t+=+r.dataset.p*+r.querySelector('i').textContent);totEl.textContent='₹'+t;return t}
document.querySelectorAll('.ord').forEach(b=>b.addEventListener('click',e=>{e.preventDefault();okEl.textContent='';openMenu()}));
// card par click karne se bhi menu khulega
document.querySelectorAll('.card').forEach(k=>k.addEventListener('click',()=>{okEl.textContent='';openMenu()}));
document.getElementById('mx').onclick=closeMenu;
mn.addEventListener('click',e=>{if(e.target===mn)closeMenu()});
addEventListener('keydown',e=>{if(e.key==='Escape')closeMenu()});
rows.forEach(r=>{const n=r.querySelector('i');
  r.querySelector('.pl').onclick=()=>{n.textContent=+n.textContent+1;total()};
  r.querySelector('.mi').onclick=()=>{n.textContent=Math.max(0,+n.textContent-1);total()};
});
document.getElementById('place').addEventListener('click',e=>{e.preventDefault();
  const t=total();okEl.textContent=t?`Order placed! Total ₹${t} ☕`:'Pehle koi drink add karo';
  if(t)setTimeout(()=>{rows.forEach(r=>r.querySelector('i').textContent=0);total();closeMenu()},1800)});
// progress bar + hero parallax
addEventListener('scroll',()=>{
  const h=document.documentElement;
  document.getElementById('prog').style.width=(h.scrollTop/(h.scrollHeight-h.clientHeight)*100)+'%';
  const hero=document.querySelector('#s0 h1');
  if(hero)hero.style.transform=`translateY(${scrollY*.25}px)`;
});